# Music license

"Happy Beats / Business Moves" Vol. 1, 9, 10, 11, 12 by Sascha Ende (https://ende.app/en),
licensed under CC BY 4.0 (https://ende.app/en/standard-license).

Required credit: Музыка: Sascha Ende, ende.app (CC BY 4.0)

Beat-grid files in cues/ come from the /brag skill by latent-spaces (MIT): https://github.com/latent-spaces/brag
